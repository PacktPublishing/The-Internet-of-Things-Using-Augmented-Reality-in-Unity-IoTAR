Heart Unity Asset:
Go to the Unity asset store to buy the animated heart model. You can look for a free version of this model if you 
prefer.

https://www.assetstore.unity3d.com/en/#!/content/27521
-----------------------------------------------------------------------------------------
Heart Rate Beat monitor Unity Asset:
This Asset is a required for the tutorial if you want to link the custom scripts to it. 

https://www.assetstore.unity3d.com/en/#!/content/6034