# IoTAR
Interenet of Things Augmented Reality Course By Ritesh Kanjee

# Video Course
Check out the full video Course on Udemy: https://www.udemy.com/internet-of-things-using-augmented-reality-and-unity-iotar/?couponCode=IOTAR_GITHUB
