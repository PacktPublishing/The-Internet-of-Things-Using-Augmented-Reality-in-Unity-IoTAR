----------------------------------------------------------------------------------------
GPU Graph Unity Asset:
This Asset is a required for the tutorial if you want to link the custom scripts to it. 

https://www.assetstore.unity3d.com/en/#!/content/72998